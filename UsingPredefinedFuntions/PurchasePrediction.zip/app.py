import gradio as gr
import numpy as np
import pickle

# Load model and scaler
with open('model.pkl', 'rb') as f:
    classifier = pickle.load(f)

with open('scaler.pkl', 'rb') as f:
    sc = pickle.load(f)

def predict_purchase(age, salary):
    try:
        X = np.array([[int(age), int(salary)]])
        X_scaled = sc.transform(X)
        result = classifier.predict(X_scaled)[0]
        return "✅ Will Purchase" if result == 1 else "❌ Will Not Purchase"
    except Exception as e:
        return f"Error: {str(e)}"

iface = gr.Interface(
    fn=predict_purchase,
    inputs=[gr.Number(label="Age"), gr.Number(label="Salary")],
    outputs=gr.Text(label="Prediction"),
    title="🧠 Purchase Predictor",
    description="Enter age and salary to predict purchase behavior."
)

if __name__ == "__main__":
    iface.launch()
